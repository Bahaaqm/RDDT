#!/usr/bin/perl
####################################################################################
# Copyright (c) 2019, Faculty of Engineering
# University of Kufa, Al Najaf, Iraq
#
####################################################################################
#RDDT: A tool to detect Inter-domain routing disruptions
#
# This software was developed by Bahaa Al-Musawi <bahaa.almusawi@uokufa.edu.iq>
# All rights reserved.
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
# 1. Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions and the following disclaimer in the
#    documentation and/or other materials provided with the distribution.
# 3. The names of the authors, the "Centre for Advanced Internet Architecture"
#    and "Swinburne University of Technology" may not be used to endorse
#    or promote products derived from this software without specific
#    prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE AUTHORS AND CONTRIBUTORS "AS IS" AND
# ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
# OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
# OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
# SUCH DAMAGE.
# Please e-mail any bugs, suggestions and feature requests to <balmusawi@swin.edu.au>
###############################################################################

# import the necessary modules
use Net::BGP::Process;
use Net::BGP::Peer;
use Time::HiRes qw(usleep);
use Time::HiRes qw(gettimeofday);
use Getopt::Long;
use Statistics::Basic qw(:all);
use Tie::File;
use File::Path;
use Mail::Sender;
use List::Util 'sum'; # this is for checking no data received (need to be changed no peer!!)

my $help = <<EOF;
RDDT : Real-Time Inter-domain Disruptions Detection Tool script.

usage:
 rddt.pl
  -colas <AS number>	# rddt AS number
  -colip <IP address>	# rddt IP address
  -peeras <AS number>	# peer AS number
  -peerip <IP address>	# peer IP address
  -email <1,0>		# 1=>send email notification or 0=> don't
  -plot <1,0>		# 1=>run real-time plot or 0=> don't
  [-help]		# Display BRT tool help

EOF

my $holdtime = 60;
my $keepalive = 20;
my ($colas, $colip, $peeras, $peerip);
my $opthelp = 0;
my $start=1;
my $counter=1;
my $pointer=1;
my $message; my $connection_check=0;
my $check=0;
my (@mylist, @volume, @TTV, @T2V, @path) = ();
my (@TTP, @T2P, @alarm) = ();
my $anomaliesdir="anomaly_timestamps";

# if the directory <anomaly_timestamps> contains files from previous running delete them
if ( -d $anomaliesdir ){
	rmtree $anomaliesdir;
	mkdir $anomaliesdir or die "Failed to create $anomaliesdir";
}else {
	mkdir $anomaliesdir or die "Failed to create $anomaliesdir";
}
# create plot.txt file that log BGP features and detected BGP anomalies
open my $plot_file,'+>>',"$anomaliesdir/plot.txt";

# Assign the necessary parameters based on the values in the configuration file
open mail_file, '<',"configuration.txt";
tie @configuration, 'Tie::File', \*mail_file or die;
my $time_delay=(split/"/,@configuration[4])[1];
my $embedding_dimension=(split/"/,@configuration[5])[1];
my $threshold=(split/"/,@configuration[6])[1];
my $email_ID=(split/"/,@configuration[10])[1];
my $email_PSW=(split/"/,@configuration[11])[1];
my $email_SMTP=(split/"/,@configuration[12])[1];
my $email_port=(split/"/,@configuration[13])[1];
my $email_from=(split/"/,@configuration[14])[1];
my $email_to=(split/"/,@configuration[15])[1];


sub my_timer_callback {

my ($peer) = shift(@_);
if (scalar @volume < 200){
	push @alarm,0;
}
if (scalar @volume > 200){
    shift @volume;
    shift @path;
}
if (scalar @volume ==200){
	open my $file_volume,'>',"/tmp/volume";
    open my $file_path,'>',"/tmp/path";
    print $file_volume join ("\n", @volume);
    print $file_path join ("\n", @path);
    print $file_volume("\n");
    print $file_path("\n");
	if ($plot==1){
		system("bash realtime.sh 2>/dev/null &");
		$plot=0;
	}
    my @v=qx(./rqa/recurrence $time_delay $embedding_dimension $threshold /tmp/volume);
    push @TTV, @v[0]; push @T2V, @v[1];
    my @p=qx(./rqa/recurrence $time_delay $embedding_dimension $threshold /tmp/path);
    push @TTP, @p[0]; push @T2P, @p[1];
    if (scalar @TTV > 1200){
        if ($pointer==0){
            if (detection (@TTV)){
                print "TTV Alarm";
				log_anomalies();
                }
            elsif (detection (@T2V)){
                print "T2V Alarm";
				log_anomalies();
                }
            elsif (detection (@TTP)){
                print "TTP Alarm";
				log_anomalies();
                }
            elsif (detection (@T2P)){
                print "T2P Alarm";
				log_anomalies();
                }
			else {
				push @alarm,0;
				}
        }
        elsif ($pointer < 200){
			$pointer+=1;
			push @alarm,0;
            }
        else{
            push @alarm,0;
			$pointer=0;
            }
        shift @TTV; shift @T2V;
        shift @TTP; shift @T2P;
    }
	else{
		push @alarm,0;
	}
} 
if (scalar @mylist < 1) {
    push @volume, "0";
    push @path, "0";
} else {
        if ($announ > 1){
        $av=$len/$announ;
        } else {
                    $av=0;
            }
        push @volume, "$volume";
        push @path, "$av";     
    }
@mylist = (); $volume = 0; $announ = 0; $as_path = 0;
if ($check==0){
	print $plot_file join ("\t", @volume[-1], @path[-1], @alarm[-1]);
	print $plot_file("\n");}
else{
	$check=0;
}

}

sub sub_open_callback
{
    #print "connection is established\n";
}

sub sub_keepalive_callback
{
    #print "keepalive received\n";

}

sub sub_reset_callback
{
   #print "connection is reset\n";
}

sub sub_error_callback
{
    my ($peer) = shift(@_);
    my ($error) = shift(@_);
    if ( $error->error_subcode()) { 
        print  $error->error_code(),"  $error_subcode \n";
        print "error in the connection\n";
    }
}

# This subroutine to calculate the needed statistical analysis at moving average stage
sub detection {
my $new_value=pop @_;
my $mean=mean(@_);
my $stddev=stddev(@_);
if (($new_value>($mean+9*$stddev))||($new_value<($mean-9*$stddev))){
	return (1);
}else{
	return (0);
}
}

# This subroutine to do the necessary actions when an anomaly occurs
sub log_anomalies
{
	my $timestamp=localtime();
	print "$timestamp\n";
	push @alarm,100;
	$pointer+=1;
	my @array=();
	open my $file_name,'>>',"$anomaliesdir/detected_anomaly_$counter.txt";
	print $plot_file join ("\t", @volume[-1], @path[-1], @alarm[-1]);
	print $plot_file("\n");
	$check=1;
	print $file_name("$timestamp\n");
	tie @array, 'Tie::File', \*$plot_file or die;
	for (my $i=(scalar @array-1200);$i<=(scalar @array-1);$i++){
		print $file_name @array[$i],"\n";
	}
	close $file_name;
	if ($email==1){
		$message="RTBADT:A new BGP Anomaly has been detected";
		sub_send_email($message);
	}
	$counter+=1;		
	return();
}

# This subroutine is necessary when e-mail option is enabled
sub sub_send_email
{
	my $sender = new Mail::Sender 
	{
		auth => 'PLAIN',
		authid => $email_ID,
		authpwd => $email_PSW,
		smtp => $email_SMTP,
		port => $email_port,
		from => $email_from,
		to => $email_to,
		subject => $message,
	};

	$sender->MailFile({
			file => "$anomaliesdir/detected_anomaly_$counter.txt",
			msg => $message,
		});
}

sub sub_update_callback
{
    
    #print "update received\n";
    my ($peer) = shift(@_);
    my ($update) = shift(@_); 
	if ($start) {
		$peer->add_timer(\&my_timer_callback, 1);
		$start = 0
	}
    my $peerid =  $peer->peer_id();
    my $peeras =  $peer->peer_as();
    my $nlri_ref = $update->nlri();
    my $mp_reach_nlri_ref = $update->mp_reach_nlri();
    my $withdrawn_ref  = $update->withdrawn();
    my $mp_unreach_nlri_ref = $update->mp_unreach_nlri();
    my $locpref = $update->local_pref();
    my $med = $update->med();
    my $aspath = $update->as_path();
    my $comm_ref = $update->communities();
    my $origin = $update->origin();
    my $nexthop = $update->next_hop();
    my $aggregate = $update->aggregator();
    my $atomic_aggregate = ($update->atomic_aggregate()) ? "NAG" : "AG";
    if ($origin == IGP){
        $origin ="IGP";
    } elsif ($origin == EGP){
        $origin ="EGP";
        } elsif ($origin == INCOMPLETE){
                $origin ="INCOMPLETE";
    }

    my $line;
    foreach $prefix (@$nlri_ref) {
        my $time = int(gettimeofday());
        $volume +=1;
        $announ +=1;
        $len=length $aspath;
        push @mylist, $line;
    }

        foreach $prefix (@$mp_reach_nlri_ref) {
            my $time = int(gettimeofday());
            $volume +=1;
            $announ +=1;
            $len=length $aspath;
            push @mylist, $line;
    }
    foreach $prefix (@$withdrawn_ref) {
            my $time = int(gettimeofday());
            $volume +=1;
            push @mylist, $line;
        }
        foreach $prefix (@$mp_unreach_nlri_ref) {
            my $time = int(gettimeofday());
            $volume +=1;
            push @mylist, $line;
        }


}

# The main code
GetOptions( 
    'help'  => \$opthelp, 
    'colas=s'   => \$colas,
    'colip=s'   => \$colip,
    'peerip=s'  => \$peerip,
    'peeras=s'  => \$peeras,
	'plot=i'  => \$plot,
	'email=i' => \$email,
 );

if ($opthelp) {
    die($help);
}

if (!($colas && $colip && $peeras && $peerip)) {
    print "Please provide colas, colip, peeras and peerip!\n";
    die($help);
}

if (!$plot) {
	$plot=0;
}
if (!$email) {
	$email=0;
}

$bgp  = Net::BGP::Process->new(Port => 179, ListenAddr =>$colip);
$peer = Net::BGP::Peer->new(
        Start    => 0,
        ThisID   => $colip,
        ThisAS   => $colas,
        PeerID   => $peerip,
        PeerAS   => $peeras,
        HoldTime => $holdtime,
        KeepAliveTime => $keepalive,
        Listen  => 1,
        KeepaliveCallback    => \&sub_keepalive_callback,
        UpdateCallback       => \&sub_update_callback,
        NotificationCallback => \&sub_notification_callback,
        ErrorCallback        => \&sub_error_callback,
        OpenCallback        => \&sub_open_callback,
        ResetCallback       => \&sub_reset_callback,
);

$bgp->add_peer($peer);
$peer->start();
print "RDDT tool started\n";
$bgp->event_loop();