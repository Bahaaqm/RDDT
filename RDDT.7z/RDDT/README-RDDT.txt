Bahaa Al-Musawi	<bahaa.almusawi@uokufa.edu.iq>                                                                                                                        
Faculty of Engineering,                                                                                                  
University of Kufa,                                                                                                          
Al Najaf, Iraq                                                                                                                                                                                                                                                

23th September, 2019

----------------------------------------------
OVERVIEW                                      
----------------------------------------------

Real-Time Inter-domain routing Disruption Detection Tool (RDDT) is a tool for UNIX
operating systems. To detect Inter-domain  routing disruptions as AS-level,
RDDT is peered with the intended AS to detect disruptions.

RDDT tool save inter-domain routing features and the detected disruptions in plot.txt
file located in <anomaly_timestamp> directory. RDADT needs many parameters
which can be changed in configuration.txt file. BGP session and message
handling are done by Net::BGP v0.16,a Perl module that implementsBGP-4
inter-domain routing protocol.
This tool helps ISPs operators to detect BGP anomalies at an early stage.

-----------------------
LICENCE                
-----------------------

This tool is released under a new BSD License. For more details
please refer to the included source files.

-----------------------
USAGE                  
-----------------------
Before running the tool, users need to use the appropriate parameters in the
configuration file <configuration.txt>.
  
Execute the script as follows:

        perl rddt.pl -colas 65003 -colip 10.0.0.49 -peeras 650002 -peerip 10.0.0.20 -plot 1 -email 1

The arguments are:
  -colas <AS number>    # RDDT AS number
  -colip <IP address>   # RDDT IP address
  -peeras <AS number>   # AS number for the intended AS
  -peerip <IP address>  # IP address for the intended AS
  -email <1,0>  # 1=> send email notification, 0=> don't
  -plot <1,0>  # 1=> run real-time plot, 0=> don't
  [-help]           # Display RDDT tool help

Example 1:
    perl rddt.pl -colas 65003 -colip 10.0.0.49 -peeras 650002 -peerip 10.0.0.20 -email 1 -plot 1

----------------------
INSTALL PERL MODULES
----------------------

RTBADT v0.1 needs Net::BGP and IO::Socket::INET6 to be install Perl modules to
work properly. To install these module use:

    #perl -MCPAN -e shell
    cpan[1]> install Net::BGP
    cpan[1]> install IO::Socket::INET6

You also need to apply IPV6 patch
    # tar xzfv rtbadt-0.1.tgz
    # cd rtbadt-0.1/patch/
    # ./patch.sh
	
Furthermore, the following modules need to be installed.
	#perl -MCPAN -e shell
    cpan[1]> Getopt::Long
	cpan[1]> Statistics::Basic

Enabling real-time GUI option requires installing gnuplot. To install gnuplot

	#apt-get install gnuplot-x11

While enabling e-mail notification requires installing Mail::Sender module.
This can be instlled by:
	#perl -MCPAN -e shell
	cpan[1]> Mail::Sender

----------------------------------------------
ADDITIONAL INFORMATION
----------------------------------------------

RDDT tool and other scripts are available at:
    https://github.com/Bahaaqm/RDDT
