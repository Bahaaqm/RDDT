#!/usr/bin/perl
use Tie::File;
use Mail::Sender;
open mail_file, '<',"configuration.txt";
tie @array, 'Tie::File', \*mail_file or die;
my $email_ID=(split/"/,@array[10])[1];
my $email_PSW=(split/"/,@array[11])[1];
my $email_SMTP=(split/"/,@array[12])[1];
my $email_port=(split/"/,@array[13])[1];
my $email_from=(split/"/,@array[14])[1];
my $email_to=(split/"/,@array[15])[1];

$message="RTBADT: configure your email setting for first use. \n If you get this e-mail, you have successfully setting up e-mail notification";
sub_email($message);

sub sub_email
{ 
	my $sender = new Mail::Sender 
	{
		auth => 'PLAIN',
		authid => $email_ID,
		authpwd => $email_PSW,
		smtp => $email_SMTP,
		port => $email_port,
		from => $email_from,
		to => $email_to,
		subject => 'RTBADT: configure your email setting for first use',
	};

	$sender->MailFile({
			file => "./test_email.pl",
			msg => $message,	
	});
}