#!/usr/bin/perl
####################################################################################
# Copyright (c) 2019, Faculty of Engineering
# University of Kufa, Al Najaf, Iraq
#
####################################################################################
#PARAMETER v0.1: A Perl script to calculate the values of RQA parameters time delay
#and embedding dimension using mutual information and false nearest neighbour methods.
# To calculate these parameters, we use mutual information and false nearest neighbour
# scripts which are available in rqa directory. These script within TISEAN pack 
#available on https://www.pks.mpg.de/~tisean/Tisean_3.0.1/index.html.
#
# This software was developed by Bahaa Al-Musawi <balmusawi@swin.edu.au>
# All rights reserved.
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
# 1. Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions and the following disclaimer in the
#    documentation and/or other materials provided with the distribution.
# 3. The names of the authors, the "Centre for Advanced Internet Architecture"
#    and "Swinburne University of Technology" may not be used to endorse
#    or promote products derived from this software without specific
#    prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE AUTHORS AND CONTRIBUTORS "AS IS" AND
# ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHORS OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
# OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
# OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
# SUCH DAMAGE.
# Please e-mail any bugs, suggestions and feature requests to <balmusawi@swin.edu.au>
###############################################################################

# import the necessary modules
use Net::BGP::Process;
use Net::BGP::Peer;
use Time::HiRes qw(usleep);
use Time::HiRes qw(gettimeofday);
use Getopt::Long;
use Tie::File;
use File::Path;

my $help = <<EOF;
RDDT : Real-Time Inter-domain routing Disruptions Detection Tool script.

usage:
 rddt.pl
  -colas <AS number>	# rddt AS number
  -colip <IP address>	# rddt IP address
  -peeras <AS number>	# peer AS number
  -peerip <IP address>	# peer IP address
  [-help]		# Display BRT tool help

EOF

my $holdtime = 60;
my $keepalive = 20;
my ($colas, $colip, $peeras, $peerip);
my $opthelp = 0;
my $start=1;
my $check=0;
my (@mylist, @volume, @alarm, @path) = ();
my $file="plot.txt";
if ( -f $file ){
	rmtree $file;
}
# create plot.txt file that log BGP features and detected BGP anomalies
open my $plot_file,'+>>',$file;

sub my_timer_callback {

my ($peer) = shift(@_);
if (scalar @volume < 200){
	push @alarm,0;
}

if (scalar @volume ==200){
	print "collected 200 seconds of BGP traffic. Now, calculate RQA parameters and edit the configuration file.\n";
	exit;
}
if (scalar @mylist < 1) {
    push @volume, "0";
    push @path, "0";
} else {
        if ($announ > 1){
        $av=$len/$announ;
        } else {
                    $av=0;
            }
        push @volume, "$volume";
        push @path, "$av";     
    }
@mylist = (); $volume = 0; $announ = 0; $as_path = 0;
print $plot_file join ("\t", @volume[-1], @path[-1], @alarm[-1]);
print $plot_file("\n");
}
sub sub_open_callback
{
    #print "connection is established\n";
}

sub sub_keepalive_callback
{
    #print "keepalive received\n";

}

sub sub_reset_callback
{
   #print "connection is reset\n";
}

sub sub_error_callback
{
    my ($peer) = shift(@_);
    my ($error) = shift(@_);
    if ( $error->error_subcode()) { 
        print  $error->error_code(),"  $error_subcode \n";
        print "error in the connection\n";
    }
}

sub sub_update_callback
{
    
    #print "update received\n";
    my ($peer) = shift(@_);
    my ($update) = shift(@_); 
	if ($start) {
		$peer->add_timer(\&my_timer_callback, 1);
		$start = 0
	}
    my $peerid =  $peer->peer_id();
    my $peeras =  $peer->peer_as();
    my $nlri_ref = $update->nlri();
    my $mp_reach_nlri_ref = $update->mp_reach_nlri();
    my $withdrawn_ref  = $update->withdrawn();
    my $mp_unreach_nlri_ref = $update->mp_unreach_nlri();
    my $locpref = $update->local_pref();
    my $med = $update->med();
    my $aspath = $update->as_path();
    my $comm_ref = $update->communities();
    my $origin = $update->origin();
    my $nexthop = $update->next_hop();
    my $aggregate = $update->aggregator();
    my $atomic_aggregate = ($update->atomic_aggregate()) ? "NAG" : "AG";
    if ($origin == IGP){
        $origin ="IGP";
    } elsif ($origin == EGP){
        $origin ="EGP";
        } elsif ($origin == INCOMPLETE){
                $origin ="INCOMPLETE";
    }

    my $line;
    foreach $prefix (@$nlri_ref) {
        my $time = int(gettimeofday());
        $volume +=1;
        $announ +=1;
        $len=length $aspath;
        push @mylist, $line;
    }

        foreach $prefix (@$mp_reach_nlri_ref) {
            my $time = int(gettimeofday());
            $volume +=1;
            $announ +=1;
            $len=length $aspath;
            push @mylist, $line;
    }
    foreach $prefix (@$withdrawn_ref) {
            my $time = int(gettimeofday());
            $volume +=1;
            push @mylist, $line;
        }
        foreach $prefix (@$mp_unreach_nlri_ref) {
            my $time = int(gettimeofday());
            $volume +=1;
            push @mylist, $line;
        }


}

# The main code
GetOptions( 
    'help'  => \$opthelp, 
    'colas=s'   => \$colas,
    'colip=s'   => \$colip,
    'peerip=s'  => \$peerip,
    'peeras=s'  => \$peeras,
 );

if ($opthelp) {
    die($help);
}

if (!($colas && $colip && $peeras && $peerip)) {
    print "Please provide colas, colip, peeras and peerip!\n";
    die($help);
}

$bgp  = Net::BGP::Process->new(Port => 179, ListenAddr =>$colip);
$peer = Net::BGP::Peer->new(
        Start    => 0,
        ThisID   => $colip,
        ThisAS   => $colas,
        PeerID   => $peerip,
        PeerAS   => $peeras,
        HoldTime => $holdtime,
        KeepAliveTime => $keepalive,
        Listen  => 1,
        KeepaliveCallback    => \&sub_keepalive_callback,
        UpdateCallback       => \&sub_update_callback,
        NotificationCallback => \&sub_notification_callback,
        ErrorCallback        => \&sub_error_callback,
        OpenCallback        => \&sub_open_callback,
        ResetCallback       => \&sub_reset_callback,
);

$bgp->add_peer($peer);
$peer->start();
$bgp->event_loop();